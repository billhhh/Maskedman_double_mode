#include "visualcontrol.h"

VisualControl::VisualControl(QWidget *parent, Qt::WFlags flags)
	: QMainWindow(parent, flags)
{

}

VisualControl::~VisualControl()
{

}
